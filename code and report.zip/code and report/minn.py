import tkinter as tk
from tkinter import ttk
import json
import subprocess
import os

# Function to handle submission
def submit():
    # Get values from input fields and convert them to string
    age_value = str(age_entry.get())
    gender_value = str(gender_var.get())
    usage_frequency_value = str(usage_frequency_entry.get())
    support_calls_value = str(support_calls_entry.get())
    payment_delay_value = str(payment_delay_entry.get())
    subscription_type_value = str(subscription_type_var.get())
    contract_length_value = str(contract_length_var.get())
    total_spend_value = str(total_spend_entry.get())
    last_interaction_value = str(last_interaction_entry.get())

    # Construct JSON payload
    json_payload = {
        "instances": [
            {
                "Age": age_value,
                "Gender": gender_value,
                "Usage_frequency": usage_frequency_value,
                "Support_calls": support_calls_value,
                "Payment_delay": payment_delay_value,
                "Subscription_type": subscription_type_value,
                "Contract_length": contract_length_value,
                "Total_spend": total_spend_value,
                "Last_interaction": last_interaction_value
            }
        ]
    }

    # Convert JSON payload to string
    json_data = json.dumps(json_payload)

    # Define the endpoint URL for your AutoML model prediction
    endpoint_url = "https://us-central1-aiplatform.googleapis.com/v1/projects/890165237853/locations/us-central1/endpoints/7883566540874842112:predict"

    # Construct curl command
    curl_command = [
        'curl', '-X', 'POST',
        '-H', 'Authorization: Bearer ya29.a0AXooCgvx5iHzxoqjSrIW4m4MYFNuTk694vTFi_sllH-0_KJ0gxZiOeTTFwvBSvk7hKZSBbMIUTPpWjUjTHzGsIKYG2PDwp4wb1kAf6EL4kmegEAHg990ZMW5RK0Gyxvjo9lbLOPvg7JOOcGRYUjQzqAjRE2RIEfNbW2Zq7JNZgaCgYKAVISARMSFQHGX2MivQbofsUel0bE4Lf2ZkZ-IA0177',

        '-H', 'Content-Type: application/json; charset=utf-8',
        '-d', json_data,
        endpoint_url
    ]

    try:
        # Execute curl command
        curl_result = subprocess.run(curl_command, capture_output=True, text=True, check=True)
        print(f"JSON payload sent successfully: {curl_result.stdout}")

    except subprocess.CalledProcessError as e:
        print(f"Error with curl command: {str(e)}")
    except Exception as e:
        print(f"Error: {str(e)}")

# Create GUI window
root = tk.Tk()
root.title("Customer Data Input")

# Create and pack input fields and labels
input_frame = ttk.Frame(root, padding="10")
input_frame.grid(row=0, column=0, sticky="nsew")

# Age
ttk.Label(input_frame, text="Age:").grid(row=0, column=0)
age_entry = ttk.Entry(input_frame, width=30)
age_entry.grid(row=0, column=1)

# Gender (Radio button)
ttk.Label(input_frame, text="Gender:").grid(row=1, column=0)
gender_var = tk.StringVar()
gender_var.set("Female")  # Default value
for idx, gender in enumerate(['Female', 'Male']):
    ttk.Radiobutton(input_frame, text=gender, variable=gender_var, value=gender).grid(row=1, column=idx+1)

# Usage Frequency
ttk.Label(input_frame, text="Usage Frequency:").grid(row=2, column=0)
usage_frequency_entry = ttk.Entry(input_frame, width=30)
usage_frequency_entry.grid(row=2, column=1)

# Support Calls
ttk.Label(input_frame, text="Support Calls:").grid(row=3, column=0)
support_calls_entry = ttk.Entry(input_frame, width=30)
support_calls_entry.grid(row=3, column=1)

# Payment Delay
ttk.Label(input_frame, text="Payment Delay:").grid(row=4, column=0)
payment_delay_entry = ttk.Entry(input_frame, width=30)
payment_delay_entry.grid(row=4, column=1)

# Subscription Type (Radio button)
ttk.Label(input_frame, text="Subscription Type:").grid(row=5, column=0)
subscription_type_var = tk.StringVar()
subscription_type_var.set("Premium")  # Default value
for idx, subscription_type in enumerate(['Premium', 'Basic', 'Standard']):
    ttk.Radiobutton(input_frame, text=subscription_type, variable=subscription_type_var, value=subscription_type).grid(row=5, column=idx+1)

# Contract Length (Radio button)
ttk.Label(input_frame, text="Contract Length:").grid(row=6, column=0)
contract_length_var = tk.StringVar()
contract_length_var.set("Monthly")  # Default value
for idx, contract_length in enumerate(['Monthly', 'Annual', 'Quarterly']):
    ttk.Radiobutton(input_frame, text=contract_length, variable=contract_length_var, value=contract_length).grid(row=6, column=idx+1)

# Total Spend
ttk.Label(input_frame, text="Total Spend:").grid(row=7, column=0)
total_spend_entry = ttk.Entry(input_frame, width=30)
total_spend_entry.grid(row=7, column=1)

# Last Interaction
ttk.Label(input_frame, text="Last Interaction:").grid(row=8, column=0)
last_interaction_entry = ttk.Entry(input_frame, width=30)
last_interaction_entry.grid(row=8, column=1)

# Submit button
submit_button = ttk.Button(root, text="Submit", command=submit)
submit_button.grid(row=1, column=0, pady=10)

root.mainloop()
